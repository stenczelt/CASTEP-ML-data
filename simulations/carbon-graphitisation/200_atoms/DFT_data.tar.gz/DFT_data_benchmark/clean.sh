#!/bin/bash

# This script is used to check failed CASTEP jobs by iterating through all the directories and checking the .err files in each directory.
for density in $(seq 1.5 0.5 3.5); do
    for temperature in $(seq 2000 500 4000); do
        for time in $(seq 400000 10000 500000); do
            cd "${density}/${temperature}K/${time}"
            # List all the .err files in the directory and print them to the terminal. If not there, then print empty line
            # Add to a text file

            # remove unnecessary files
            rm -rf *.param
            cd ../../../
            echo "Done with ${density}/${temperature}K/${time}"
            
        done
    done
done
